function likePost(btn){
let text = btn.innerHTML;
let num = parseInt(text.replace(/\D/g,''));
num++;
btn.innerHTML = "❤️ " + num;
}